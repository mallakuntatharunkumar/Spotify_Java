package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Home extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String Email = req.getParameter("email");
        String Password = req.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys", "root", "9542243682");

            String query = "SELECT * FROM registe WHERE Email = ? AND Password = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, Email);
            pst.setString(2, Password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
            	RequestDispatcher dispatch = req.getRequestDispatcher("Spotify.html");
				dispatch.forward(req, resp);
            } else {
                out.println("<html><head><title>Login Failed</title></head><body style='text-align: center; background-color: #ffe6e6;'>");
                out.println("<h1 style='color: red;'>Login Credentials are wrong</h1>");
                RequestDispatcher d = req.getRequestDispatcher("login.html");
                d.include(req, resp);
                out.println("</body></html>");
            }

           
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<html><head><title>Error</title></head><body style='text-align: center; background-color: #ffcccc;'>");
            out.println("<h1 style='color: red;'>Error occurred: " + e.getMessage() + "</h1>");
            out.println("</body></html>");
        }
    }
}
