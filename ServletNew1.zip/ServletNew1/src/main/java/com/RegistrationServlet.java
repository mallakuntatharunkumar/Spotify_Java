package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reg_success")
public class RegistrationServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		String name = req.getParameter("Name");
		String email = req.getParameter("Email");
		String password = req.getParameter("Password");
		int age = Integer.parseInt(req.getParameter("Age"));
		String country = req.getParameter("Country");
		String url = "jdbc:mysql://localhost:3306/sys";
		String user = "root";
		String pass = "9542243682";  
		String query = "INSERT INTO registe VALUES (?, ?, ?, ?, ?)";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, pass);
		     PreparedStatement p = con.prepareStatement(query) ;
			p.setString(1, name);
			p.setString(2, email);
			p.setString(3, password);
			p.setInt(4, age);
			p.setString(5, country);
			
			int i = p.executeUpdate();
			if (i > 0) {
				out.println("<h3>Registration successful</h3>");
				RequestDispatcher dispatch = req.getRequestDispatcher("Spotify.html");
				dispatch.forward(req, resp);
			}
			
		} catch (Exception e) {
		    e.printStackTrace(out); 
		    out.println("<h3>Registration failed. Error: " + e.getMessage() + "</h3>");
		}

	}
}
